import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
import pandas as pd
from scipy.optimize import minimize

# خواندن داده‌ها از فایل اکسل
data = pd.read_excel("user_data.xlsx")
closeness = data['closeness'].values
popularity = data['popularity'].values
trust = data['trust'].values

num_users = len(closeness)

# ایجاد شبکه اجتماعی تصادفی با num_users کاربر
graph = nx.erdos_renyi_graph(num_users, 0.0005, seed=42, directed=True)

# احتمال ارسال اطلاعات
def probability_send(c, p, t, alpha=0.4, beta=0.3, gamma=0.3):
    return alpha * c + beta * p + gamma * t

p_send = np.array([probability_send(closeness[i], popularity[i], trust[i]) for i in range(num_users)])

# تعریف تابع هزینه برای هر کاربر (نظریه بازی)
def cost_function(prob):
    return -np.sum(prob * np.log(prob + 1e-9))  # منفی مجموع اطلاعات متقابل

# بهینه‌سازی استراتژی کاربران برای یافتن تعادل نش
result = minimize(cost_function, p_send, bounds=[(0,1)]*num_users, method='L-BFGS-B')
nash_equilibrium = result.x

# شبیه‌سازی انتشار اطلاعات
def simulate_spread(graph, nash_eq, threshold=0.5, steps=10):
    active_nodes = set(np.random.choice(list(graph.nodes), 50, replace=False))  # افزایش تعداد کاربران اولیه
    spread_count = [len(active_nodes)]
    
    for _ in range(steps):
        new_active_nodes = set()
        for node in active_nodes:
            neighbors = set(graph.successors(node))
            for neighbor in neighbors:
                if nash_eq[neighbor] > threshold:
                    new_active_nodes.add(neighbor)
        active_nodes.update(new_active_nodes)
        spread_count.append(len(active_nodes))
        if not new_active_nodes:
            break
    return spread_count

# اجرای شبیه‌سازی و رسم نمودار انتشار
spread_data = simulate_spread(graph, nash_equilibrium)
plt.figure(figsize=(10, 6))
plt.plot(spread_data, marker='o', linestyle='-', color='red')
plt.title("Spread of Information Over Time ({} Users)".format(num_users))
plt.xlabel("Iteration Step")
plt.ylabel("Total Infected Users")
plt.grid(axis='both', linestyle='--', alpha=0.7)
plt.show()

# رسم نمودار توزیع احتمال ارسال اطلاعات
plt.figure(figsize=(10, 6))
plt.hist(p_send, bins=50, color='blue', alpha=0.7)
plt.title("Distribution of Information Sending Probability")
plt.xlabel("Probability Value")
plt.ylabel("Number of Users")
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.show()

# رسم گراف شبکه اجتماعی
plt.figure(figsize=(8, 8))
pos = nx.spring_layout(graph, seed=42)
nx.draw(graph, pos, node_size=10, edge_color='gray', alpha=0.5)
plt.title("Social Network Graph")
plt.show()

# رسم نمودار تغییرات تعادل نش در کاربران
plt.figure(figsize=(10, 6))
plt.hist(nash_equilibrium, bins=50, color='green', alpha=0.7)
plt.title("Distribution of Nash Equilibrium Probabilities")
plt.xlabel("Nash Equilibrium Value")
plt.ylabel("Number of Users")
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.show()
